# Semantic frontend short-sequence admission

120 frames of seq07; loop disabled; archived predictions, not live inference.

| Arm | Repetition | Poses | ATE m | RPE 1s m | RPE 1s deg | Updates with boundary constraints |
|---|---:|---:|---:|---:|---:|---:|
| geometry | 1 | 115 | 0.074490 | 0.094818 | 0.314410 | 0 |
| association_B0 | 1 | 115 | 0.073269 | 0.093659 | 0.299170 | 0 |
| boundary_B0 | 1 | 115 | 0.073440 | 0.094311 | 0.315042 | 0 |
| full_B0 | 1 | 115 | 0.073525 | 0.090989 | 0.304313 | 0 |
| full_ZS | 1 | 115 | 0.071550 | 0.093605 | 0.313534 | 0 |
| association_B0 | 2 | 115 | 0.073656 | 0.092374 | 0.301571 | 0 |
| boundary_B0 | 2 | 115 | 0.076388 | 0.094544 | 0.310514 | 0 |
| full_B0 | 2 | 115 | 0.076050 | 0.093835 | 0.313325 | 0 |
| full_ZS | 2 | 115 | 0.072177 | 0.093286 | 0.319195 | 0 |
| geometry | 2 | 115 | 0.073545 | 0.093964 | 0.311293 | 0 |
| boundary_B0 | 3 | 115 | 0.073662 | 0.094194 | 0.309420 | 0 |
| full_B0 | 3 | 115 | 0.073403 | 0.093694 | 0.300755 | 0 |
| full_ZS | 3 | 115 | 0.071817 | 0.092720 | 0.315566 | 0 |
| geometry | 3 | 115 | 0.074283 | 0.094291 | 0.320484 | 0 |
| association_B0 | 3 | 115 | 0.072615 | 0.093354 | 0.294655 | 0 |

These data do not establish full-sequence or online superiority. No large experiment is authorized by this smoke alone.
