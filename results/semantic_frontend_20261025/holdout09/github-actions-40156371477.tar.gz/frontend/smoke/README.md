# Semantic frontend short-sequence admission

{'sequence': '09', 'first_frame': 0, 'end_exclusive': 240} cached-label frontend validation; not full-sequence accuracy or real-time inference

| Arm | Repetition | Poses | ATE m | RPE 1s m | RPE 1s deg | Updates with boundary constraints |
|---|---:|---:|---:|---:|---:|---:|
| geometry | 1 | 235 | 0.430914 | 0.137759 | 0.171292 | 0 |
| association_B0 | 1 | 235 | 0.542964 | 0.141282 | 0.168256 | 0 |
| boundary_B0 | 1 | 235 | 0.461249 | 0.136128 | 0.168218 | 233 |
| full_B0 | 1 | 235 | 0.411198 | 0.125020 | 0.164934 | 233 |
| full_ZS | 1 | 235 | 0.389618 | 0.129898 | 0.156205 | 224 |
| association_B0 | 2 | 235 | 0.395762 | 0.126517 | 0.160993 | 0 |
| boundary_B0 | 2 | 235 | 0.419807 | 0.135430 | 0.166098 | 233 |
| full_B0 | 2 | 235 | 0.472290 | 0.132542 | 0.176015 | 233 |
| full_ZS | 2 | 235 | 0.379615 | 0.129883 | 0.153542 | 224 |
| geometry | 2 | 235 | 0.408818 | 0.134275 | 0.164801 | 0 |
| boundary_B0 | 3 | 235 | 0.405052 | 0.135742 | 0.168171 | 233 |
| full_B0 | 3 | 235 | 0.506581 | 0.137257 | 0.166403 | 233 |
| full_ZS | 3 | 235 | 0.425463 | 0.127844 | 0.167536 | 224 |
| geometry | 3 | 235 | 0.449055 | 0.125014 | 0.162502 | 0 |
| association_B0 | 3 | 235 | 0.390982 | 0.126702 | 0.166317 | 0 |

These data do not establish full-sequence or online superiority. No large experiment is authorized by this smoke alone.
