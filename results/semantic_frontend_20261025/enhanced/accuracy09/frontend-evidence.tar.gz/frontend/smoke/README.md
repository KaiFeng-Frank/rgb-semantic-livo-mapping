# Semantic frontend short-sequence admission

{'sequence': '09', 'first_frame': 240, 'end_exclusive': 480} cached-label frontend validation; not full-sequence accuracy or real-time inference

| Arm | Repetition | Poses | ATE m | RPE 1s m | RPE 1s deg | Updates with boundary constraints |
|---|---:|---:|---:|---:|---:|---:|
| geometry | 1 | 235 | 16.201937 | 5.327161 | 1.304446 | 0 |
| association_B0 | 1 | 235 | 32.916603 | 7.065663 | 1.433112 | 0 |
| motion_B0 | 1 | 235 | 23.635404 | 5.946867 | 1.574140 | 0 |
| visual_B0 | 1 | 235 | 20.081579 | 5.738287 | 1.495822 | 0 |
| likelihood_B0 | 1 | 235 | 15.537701 | 4.957614 | 1.435145 | 0 |
| enhanced_B0 | 1 | 235 | 20.894547 | 5.921384 | 2.014813 | 0 |
| association_B0 | 2 | 235 | 34.365843 | 7.124347 | 1.454709 | 0 |
| motion_B0 | 2 | 235 | 23.644303 | 5.946871 | 1.574404 | 0 |
| visual_B0 | 2 | 235 | 20.081579 | 5.738287 | 1.495822 | 0 |
| likelihood_B0 | 2 | 235 | 15.826298 | 4.964667 | 1.400630 | 0 |
| enhanced_B0 | 2 | 235 | 20.894547 | 5.921384 | 2.014813 | 0 |
| geometry | 2 | 235 | 16.212025 | 5.327163 | 1.304451 | 0 |
| motion_B0 | 3 | 235 | 23.605742 | 5.946913 | 1.575302 | 0 |
| visual_B0 | 3 | 235 | 20.081579 | 5.738287 | 1.495822 | 0 |
| likelihood_B0 | 3 | 235 | 15.464950 | 5.160105 | 1.408502 | 0 |
| enhanced_B0 | 3 | 235 | 20.894547 | 5.921384 | 2.014813 | 0 |
| geometry | 3 | 235 | 16.199229 | 5.327159 | 1.304578 | 0 |
| association_B0 | 3 | 235 | 33.260206 | 7.077812 | 1.433029 | 0 |

These data do not establish full-sequence or online superiority. No large experiment is authorized by this smoke alone.
